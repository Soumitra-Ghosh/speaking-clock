package com.controller.test;

import com.example.demo.controller.SpeakingClockController;
import com.example.demo.service.SpeakingClockService;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@WebMvcTest(SpeakingClockController.class)
public class SpeakingClockControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SpeakingClockService speakingClockService;

    @Test
    public void testConvertToWordsEndpoint() throws Exception {
        when(speakingClockService.convertTimeToWords("08:34")).thenReturn("It's eight thirty four");

        mockMvc.perform(get("/api/speaking-clock/convert")
                .param("time", "08:34"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(true))
                .andExpect(jsonPath("$.data").value("It's eight thirty four"));
    }
}

