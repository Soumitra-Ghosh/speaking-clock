package com.serviceTest;

import com.example.demo.exception.SpeakingClockException;
import com.example.demo.service.SpeakingClockService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class SpeakingClockServiceTest {

    @Autowired
    private SpeakingClockService speakingClockService;

    @Test
    public void testConvertToWords() throws SpeakingClockException {
        // Test positive scenarios
        String result = speakingClockService.convertTimeToWords("08:34");
        assertEquals("It's eight thirty four", result);

        // Test negative scenarios
        assertThrows(SpeakingClockException.class, () -> speakingClockService.convertTimeToWords("invalid"));
    }
}
