package com.example.demo;

public @interface EnableSwagger2 {

}
