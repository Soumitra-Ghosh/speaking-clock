package com.example.demo.service;

import com.example.demo.exception.SpeakingClockException;
import org.springframework.stereotype.Service;

@Service
public class SpeakingClockServiceImpl implements SpeakingClockService {

    @Override
    public String convertTimeToWords(String time) throws SpeakingClockException {
        if (!isValidTimeFormat(time)) {
            throw new SpeakingClockException("Invalid time format");
        }
                
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        
        if (hours == 12 && minutes == 0) {
            return "It's Midday";
        } else if (hours == 0 && minutes == 0) {
            return "It's Midnight";
        } else {
        

        String[] hoursWords = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen",
                "Nineteen", "Twenty"};

        if (hours > 20) {
            return "Invalid input for hours";
        }

        String minuteWord = (minutes > 0) ? " " + convertMinutsToWords(minutes) + " Minute" + ((minutes > 1) ? "s" : "") : "";
        String hoursWord = (hours > 0) ? " " + convertHoursToWords(hours) + " Hour" + ((hours > 1) ? "s" : "") :"";
        String period = (hours < 12) ? " AM" : " PM";

        return  "It's " + hoursWords[hours]+" Hours"+ " " + minuteWord + period;
    }
    }
        

    private boolean isValidTimeFormat(String time) {
             return time != null && time.matches("\\d{2}:\\d{2}");
    }

    private String convertHoursToWords(int hours) {
   
        String[] hoursWords = {
        		 "Midnight", "One", "Two", "Three", "Four", "Five",
                 "Six", "Seven", "Eight", "Nine", "Ten", "Eleven",
                 "Twelve", "Thirteen", "Fourteen", "Fifteen",
                 "Sixteen", "Seventeen", "Eighteen", "Nineteen",
                 "Twenty", "Twenty-One", "Twenty-Two", "Twenty-Three"
        };

        return hoursWords[hours % 12];
    }
    public static String convertMinutsToWords(int num) {
        String[] units = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
        String[] teens = {"", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
                "Eighteen", "Nineteen"};
        String[] tens = {"", "Ten", "Twenty", "Thirty", "Forty", "Fifty"};

        if (num == 0) {
            return "Zero";
        }

        if (num < 10) {
            return units[num];
        }

        if (num < 20) {
            return teens[num - 10];
        }

        int tensDigit = num / 10;
        int unitsDigit = num % 10;

        return tens[tensDigit] + ((unitsDigit > 0) ? " " + units[unitsDigit] : "");
    }

    
//    private String convertMinutesToWords(int minutes) {
//        // Implement conversion of minutes to words
//        // For simplicity, you can use a pre-defined list of words
//        String[] minutesWords = {
//                "O'Clock", "One", "Two", "Three", "Four", "Five",
//                "Six", "Seven", "Eight", "Nine", "Ten", "Eleven",
//                "Twelve", "Thirteen", "Fourteen", "Fifteen",
//                "Sixteen", "Seventeen", "Eighteen", "Nineteen",
//                "Twenty", "Twenty-One", "Twenty-Two", "Twenty-Three",
//                "Twenty-Four", "Twenty-Five", "Twenty-Six",
//                "Twenty-Seven", "Twenty-Eight", "Twenty-Nine", "Thirty",
//                "Thirty-One", "Thirty-Two", "Thirty-Three", "Thirty-Four",
//                "Thirty-Five", "Thirty-Six", "Thirty-Seven", "Thirty-Eight",
//                "Thirty-Nine", "Forty", "Forty-One", "Forty-Two", "Forty-Three",
//                "Forty-Four", "Forty-Five", "Forty-Six", "Forty-Seven", "Forty-Eight",
//                "Forty-Nine", "Fifty", "Fifty-One", "Fifty-Two", "Fifty-Three",
//                "Fifty-Four", "Fifty-Five", "Fifty-Six", "Fifty-Seven", "Fifty-Eight",
//                "Fifty-Nine"
//        };
//
//        if (minutes == 0) {
//            return "O'Clock";
//        } else if (minutes == 15) {
//            return "Quarter";
//        } else if (minutes == 30) {
//            return "Half";
//        } else if (minutes == 45) {
//            return "Quarters";
//        } else if (minutes < 30) {
//            return minutesWords[minutes] + " past";
//        } else {
//            return minutesWords[60 - minutes] + " to";
//        }
    
}