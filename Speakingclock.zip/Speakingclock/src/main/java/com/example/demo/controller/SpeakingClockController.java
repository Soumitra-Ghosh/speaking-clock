package com.example.demo.controller;

import com.example.demo.exception.SpeakingClockException;
import com.example.demo.response.ApiResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.service.SpeakingClockService;

@RestController
@RequestMapping("/api/speaking-clock")
public class SpeakingClockController {
	
	@org.springframework.beans.factory.annotation.Autowired(required=true)
    private SpeakingClockService speakingClockService;

    @GetMapping("/convert")
    public ApiResponse convertTimeToWords(@RequestParam String time) throws SpeakingClockException {
        try {  
            String result = speakingClockService.convertTimeToWords(time);
            return new ApiResponse(true, "Success", result);
       } 
            catch (SpeakingClockException ex) {
           return new ApiResponse(false, ex.getMessage(), null);
        }
    }
}