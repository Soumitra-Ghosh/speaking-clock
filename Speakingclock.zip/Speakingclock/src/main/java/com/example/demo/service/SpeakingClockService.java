package com.example.demo.service;

import com.example.demo.exception.SpeakingClockException;

public interface SpeakingClockService {
    String convertTimeToWords(String time) throws SpeakingClockException;
}
