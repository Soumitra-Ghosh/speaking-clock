package com.example.demo.exception;

public class SpeakingClockException extends Exception {
	
	public SpeakingClockException(String message) {
		super(message);
	}

}
